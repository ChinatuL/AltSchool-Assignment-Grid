import { range } from './utils';

function Grid({ numRows, numCols }) {
  return <div className="grid">{/* TODO */}</div>;
}

export default Grid;
